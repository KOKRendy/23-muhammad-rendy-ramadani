<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
    <title>Rendax</title>
  </head>
  <body>
    <!-- Awal Judul Produk  -->
    <br />
    <h1 class="text-center">Produk Kami</h1>
    <!-- Akhir Judul Produk -->

    <!-- Awal Content Produk -->
    <div class="container profil-card">
      <div class="row g-3">
        <?php for ($i = 1; $i <= 6; $i++) : ?>
          <div class="col-12 col-md-6 col-lg-4">
            <div class="card shadow-lg">
              <img src="img/gambar-login.jpg" class="card-img-top" alt="Foto Produk Baju" />
              <div class="card-body">
                <h5 class="card-title">Baju Anya Kawai</h5>
                <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <b><p>Rp. 250.000</p></b>
                <button class="btn btn-warning text-white rounded-pill">Beli</button>
                <a href="index.php?page=single-produk"><button class="btn btn-warning text-white rounded-pill">Lihat Produk</button></a>
                <button class="btn btn-warning text-white rounded-pill">Masukan Ke Keranjang</button>
              </div>
            </div>
          </div>
        <?php endfor; ?>
      </div>
    </div>
    <!-- Akhir Content Produk -->
  </body>
</html>
