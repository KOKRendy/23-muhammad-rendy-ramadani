<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
    <title>Rendax</title>
  </head>
  <body>
    <!-- Awal Content Produk -->
    <div class="container text-center content-single-produk">
      <div class="row g-0">
        <div class="col">
          <div class="card mb-3">
            <div class="row g-0">
              <div class="col-md-4">
                <img src="img/gambar-login.jpg" class="img-fluid rounded-start" alt="..." />
              </div>
              <div class="col-md-8 text-start">
                <div class="card-body card-body-produk">
                  <h5 class="card-title">Baju Anya Kawaii</h5>
                  <h3>Rp. 150.000</h3>
                  <br />
                  <p class="card-text">
                    This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias atque ullam quidem
                    doloremque rem ratione fugiat. Deleniti perferendis suscipit ipsum in. Aliquid officiis debitis magni enim ipsam omnis rerum in!
                  </p>
                  <div class="content-bawah-produk">
                    <button type="button" class="btn btn-warning">Beli</button>
                    <button type="button" class="btn btn-warning">Masukan Keranjang</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Awal Content Produk -->
  </body>
</html>
