<?php
unset ($_SESSION['username']);
?>
<br>
<h2 class="text-center">Anda Telah Logout</h2>