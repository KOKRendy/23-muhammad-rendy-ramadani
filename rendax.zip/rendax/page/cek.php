<?php
if  (!isset($_SESSION['username'])){
    header('Localtion: ../?page=home');
}
?>